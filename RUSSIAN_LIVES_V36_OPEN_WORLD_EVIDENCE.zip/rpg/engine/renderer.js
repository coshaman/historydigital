import { objectIsPresent, interactionTile } from './world-presentation.mjs';
import { atmosphereForMap, mapHasAtmosphere } from './atmosphere.mjs';

export function calculateCamera({ viewportWidth, viewportHeight, mapWidth, mapHeight, tileSize = 16, position, zoom = 2.25 }) {
  const mapWidthWorld = mapWidth * tileSize, mapHeightWorld = mapHeight * tileSize;
  const fitScale = Math.min(viewportWidth / mapWidthWorld, viewportHeight / mapHeightWorld);
  const scale = fitScale * zoom;
  const visibleWidth = viewportWidth / scale, visibleHeight = viewportHeight / scale;
  const centerX = (position.x + 0.5) * tileSize, centerY = (position.y + 0.5) * tileSize;
  const offsetX = mapWidthWorld <= visibleWidth
    ? (viewportWidth - mapWidthWorld * scale) / 2
    : -Math.max(0, Math.min(mapWidthWorld - visibleWidth, centerX - visibleWidth / 2)) * scale;
  const offsetY = mapHeightWorld <= visibleHeight
    ? (viewportHeight - mapHeightWorld * scale) / 2
    : -Math.max(0, Math.min(mapHeightWorld - visibleHeight, centerY - visibleHeight / 2)) * scale;
  return {
    scale,
    offsetX,
    offsetY,
    viewportWidth,
    viewportHeight,
    mapWidthPixels: mapWidthWorld * scale,
    mapHeightPixels: mapHeightWorld * scale,
    visibleTilesX: visibleWidth / tileSize,
    visibleTilesY: visibleHeight / tileSize,
    actorScreenX: offsetX + centerX * scale,
    actorScreenY: offsetY + centerY * scale,
  };
}

export function createRenderer(canvas, assets) {
  const ctx = canvas.getContext('2d', { alpha: false });
  ctx.imageSmoothingEnabled = false;
  const images = new Map();
  const mapCache = new Map();
  let latestDrawArgs = null;
  let assetFrameQueued = false;
  function redrawAfterAssetLoad() {
    if (!latestDrawArgs || assetFrameQueued) return;
    assetFrameQueued = true;
    requestAnimationFrame(() => {
      assetFrameQueued = false;
      if (latestDrawArgs) draw(...latestDrawArgs);
    });
  }
  function getImage(url) {
    if (!images.has(url)) { const image = new Image(); image.onload = () => { mapCache.clear(); redrawAfterAssetLoad(); }; image.src = url; images.set(url, image); }
    return images.get(url);
  }
  const tileImage = getImage(new URL('../assets/petersburg-tiles.png', import.meta.url));
  const hostCards = assets.hostCards;
  const tile = 16;
  const motionPreference = window.matchMedia?.('(prefers-reduced-motion: reduce)');
  let reducedMotion = motionPreference?.matches ?? false;
  motionPreference?.addEventListener?.('change', event => { reducedMotion = event.matches; redrawAfterAssetLoad(); });
  function resize() {
    const rect = canvas.getBoundingClientRect(), ratio = Math.min(window.devicePixelRatio || 1, 2);
    const width = Math.max(1, Math.round(rect.width * ratio)), height = Math.max(1, Math.round(rect.height * ratio));
    if (canvas.width !== width || canvas.height !== height) { canvas.width = width; canvas.height = height; }
    ctx.imageSmoothingEnabled = false;
  }
  function mapCanvas(map) {
    if (mapCache.has(map.mapId)) return mapCache.get(map.mapId);
    if (!tileImage.complete || !tileImage.naturalWidth) return null;
    const surface = document.createElement('canvas'); surface.width = map.width * tile; surface.height = map.height * tile;
    const paint = surface.getContext('2d'); paint.imageSmoothingEnabled = false;
    // Collision uses 1 as a boolean mask, not the cobblestone tile with gid 1.
    for (const layer of map.layers.filter(item => item.type === 'tilelayer' && item.name !== 'Collision' && item.visible !== false)) {
      for (let y = 0; y < map.height; y++) for (let x = 0; x < map.width; x++) {
        const gid = layer.data[y * map.width + x]; if (!gid) continue;
        const index = gid - 1, sx = (index % 16) * tile, sy = Math.floor(index / 16) * tile;
        paint.drawImage(tileImage, sx, sy, tile, tile, x * tile, y * tile, tile, tile);
      }
    }
    mapCache.set(map.mapId, surface);
    return surface;
  }
  function draw(state, map, time = 0, lastMoveAt = 0, objective = null) {
    latestDrawArgs = [state, map, time, lastMoveAt, objective];
    resize();
    const ratio = canvas.width / canvas.getBoundingClientRect().width;
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
    const w = canvas.clientWidth, h = canvas.clientHeight;
    const actor = state.player.embodiment ? state.hosts[state.player.embodiment] : state.player;
    const camera = calculateCamera({ viewportWidth: w, viewportHeight: h, mapWidth: map.width, mapHeight: map.height, tileSize: tile, position: actor.position });
    const { scale, offsetX: ox, offsetY: oy } = camera;
    ctx.fillStyle = '#62564b'; ctx.fillRect(0, 0, w, h);
    const background = mapCanvas(map);
    if (background) ctx.drawImage(background, ox, oy, background.width * scale, background.height * scale);
    if (map.metadata?.mapClass === 'LITERARY_REALM') {
      ctx.save();
      ctx.fillStyle = '#9a6b3822';
      ctx.fillRect(ox, oy, map.width * tile * scale, map.height * tile * scale);
      const edge = ctx.createRadialGradient(ox + map.width * tile * scale / 2, oy + map.height * tile * scale / 2, 30 * scale, ox + map.width * tile * scale / 2, oy + map.height * tile * scale / 2, Math.max(map.width * tile, map.height * tile) * scale * .72);
      edge.addColorStop(0, '#f3dfb000'); edge.addColorStop(1, '#2c181e66');
      ctx.fillStyle = edge; ctx.fillRect(ox, oy, map.width * tile * scale, map.height * tile * scale);
      ctx.restore();
    }
    const objectLayer = map.layers.find(item => item.name === 'Interactions');
    for (const object of objectLayer?.objects ?? []) {
      if (!objectIsPresent(object, state, assets.quests)) continue;
      const p = Object.fromEntries((object.properties ?? []).map(v => [v.name, v.value]));
      const x = ox + object.x * scale, y = oy + object.y * scale;
      const index = interactionTile(object) - 1;
      if (tileImage.complete && tileImage.naturalWidth) ctx.drawImage(tileImage, index % 16 * tile, Math.floor(index / 16) * tile, tile, tile, x, y, tile * scale, tile * scale);
      if (state.player.embodiment && p.questId && state.quests[p.questId]?.status === 'open') { ctx.strokeStyle = '#f0d79e'; ctx.lineWidth = 1.5; ctx.strokeRect(x + 1, y + 1, 14 * scale, 14 * scale); }
    }
    for (const card of [...hostCards].sort((a, b) => (state.hosts[a.id]?.position.y ?? 0) - (state.hosts[b.id]?.position.y ?? 0))) {
      const host = state.hosts[card.id]; if (!host || host.mapId !== map.mapId || host.historicalAliveAndPresent === false) continue;
      const atlas = card.spriteAtlas ?? card.sprite;
      const sprite = getImage(new URL(`../${atlas.file}`, import.meta.url));
      const active = state.player.embodiment === card.id;
      const frameCount = atlas.framesPerDirection ?? 3, frameWidth = atlas.frameWidth ?? 16, frameHeight = atlas.frameHeight ?? 24;
      const frame = !reducedMotion && active && time - lastMoveAt < 360 ? Math.floor(time / 120) % frameCount : 0;
      const dir = atlas.directionRows?.[host.facing] ?? ({ down: 0, up: 1, left: 2, right: 3 })[host.facing] ?? 0, px = ox + host.position.x * tile * scale, py = oy + host.position.y * tile * scale;
      if (sprite.complete && sprite.naturalWidth) ctx.drawImage(sprite, frame * frameWidth, dir * frameHeight, frameWidth, frameHeight, px, py - 8 * scale, frameWidth * scale, frameHeight * scale);
      if (state.player.embodiment === card.id) { ctx.strokeStyle = '#f2d38b'; ctx.lineWidth = 1; ctx.beginPath(); ctx.ellipse(px + 8 * scale, py + 15 * scale, 8 * scale, 3 * scale, 0, 0, Math.PI * 2); ctx.stroke(); }
    }
    const px = ox + actor.position.x * tile * scale, py = oy + actor.position.y * tile * scale;
    if (!state.player.embodiment) { ctx.fillStyle = '#efe0b5'; ctx.fillRect(px + 7 * scale, py + 5 * scale, 3 * scale, 8 * scale); ctx.fillRect(px + 5 * scale, py + 3 * scale, 7 * scale, 3 * scale); }
    // Warm paper lanterns mark the active space without covering tile detail.
    const glow = ctx.createRadialGradient(px + 8 * scale, py + 8 * scale, 2, px + 8 * scale, py + 8 * scale, 46 * scale);
    const pulse = reducedMotion ? 0.5 : (Math.sin(time / 850) + 1) / 2;
    glow.addColorStop(0, `rgba(212,163,93,${0.055 + pulse * 0.025})`); glow.addColorStop(1, '#d4a35d00'); ctx.globalCompositeOperation = 'screen'; ctx.fillStyle = glow; ctx.fillRect(ox, oy, map.width * tile * scale, map.height * tile * scale); ctx.globalCompositeOperation = 'source-over';
    const atmosphere = atmosphereForMap(map.mapId, map.width * tile * scale, map.height * tile * scale, time, reducedMotion);
    if (atmosphere) {
      ctx.save();
      ctx.beginPath(); ctx.rect(ox, oy, map.width * tile * scale, map.height * tile * scale); ctx.clip();
      if (atmosphere.kind === 'drizzle') {
        const hazeY = oy + map.height * tile * scale * (0.44 + (reducedMotion ? 0 : Math.sin(time / 2400) * 0.018));
        const haze = ctx.createLinearGradient(0, hazeY, 0, hazeY + map.height * tile * scale * 0.16);
        haze.addColorStop(0, 'rgba(182,198,202,0)'); haze.addColorStop(0.5, 'rgba(182,198,202,0.055)'); haze.addColorStop(1, 'rgba(182,198,202,0)');
        ctx.fillStyle = haze; ctx.fillRect(ox, hazeY, map.width * tile * scale, map.height * tile * scale * 0.16);
        ctx.lineWidth = 1;
        for (const drop of atmosphere.particles) {
          ctx.strokeStyle = `rgba(190,204,204,${drop.alpha})`;
          ctx.beginPath(); ctx.moveTo(ox + drop.x, oy + drop.y); ctx.lineTo(ox + drop.x - 1.5, oy + drop.y + drop.length); ctx.stroke();
        }
      } else {
        for (const mote of atmosphere.particles) {
          ctx.fillStyle = `rgba(239,207,145,${mote.alpha})`;
          ctx.fillRect(ox + mote.x, oy + mote.y, mote.size, mote.size);
        }
      }
      ctx.restore();
    }
    if (objective?.pinned && objective.target?.mapId === map.mapId) {
      const target = objective.target, x = ox + (target.x + 0.5) * tile * scale;
      const y = oy + target.y * tile * scale - 9 * scale;
      if (x >= 2 && x <= w - 2 && y >= 2 && y <= h - 2) {
        const size = Math.max(5, 4 * scale), pulse = reducedMotion ? 0 : Math.sin(time / 360) * Math.min(2, scale);
        ctx.save(); ctx.translate(x, y - pulse); ctx.rotate(Math.PI / 4);
        ctx.fillStyle = '#ffe4a6'; ctx.strokeStyle = '#39251a'; ctx.lineWidth = Math.max(1, scale * .7);
        ctx.fillRect(-size / 2, -size / 2, size, size); ctx.strokeRect(-size / 2, -size / 2, size, size); ctx.restore();
      }
    }
  }
  return { draw, needsAmbientFrames: map => mapHasAtmosphere(map.mapId) && !reducedMotion };
}

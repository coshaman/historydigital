// AI requests use the same-origin Vercel Function at /api/rpg/.

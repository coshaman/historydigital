import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { chromium } from 'playwright';

const root = process.cwd();
const require = createRequire(import.meta.url);
const engine = require('../rpg/engine/game-state.js');
const read = relative => JSON.parse(fs.readFileSync(path.join(root, relative), 'utf8'));
const maps = Object.fromEntries(fs.readdirSync(path.join(root, 'rpg/maps')).filter(file => file.endsWith('.json')).map(file => [file.slice(0, -5), read(`rpg/maps/${file}`)]));
const cards = fs.readdirSync(path.join(root, 'rpg/characters')).filter(file => file.endsWith('.json')).map(file => read(`rpg/characters/${file}`));
const quests = fs.readdirSync(path.join(root, 'rpg/quests')).filter(file => file.endsWith('.json') && file !== 'campaign.json').map(file => read(`rpg/quests/${file}`));
const browser = await chromium.launch({ headless: true, executablePath: 'C:/Program Files/Google/Chrome/Application/chrome.exe' });
const base = process.env.V33_RPG_URL || 'http://127.0.0.1:4173/';
const out = path.join(root, 'artifacts/v33/INTERPERSONAL_DIALOGUE');
fs.mkdirSync(out, { recursive: true });
const report = { status: 'PASS', viewports: [] };
const sessionStarts = [], dialogueRequests = [];
let sessionTokenNumber = 0;
let releaseSlowDialogue = null;
let fallbackNextDialogue = false;
let networkFailureNextDialogue = false;

try {
  for (const viewport of [{ width: 1440, height: 900 }, { width: 1366, height: 768 }, { width: 390, height: 844 }, { width: 360, height: 800 }]) {
    const page = await browser.newPage({ viewport });
    page.setDefaultTimeout(8000);
    const errors = [];
    page.on('pageerror', error => errors.push(String(error)));
    await page.route('**/api/rpg/session/start', async route => {
      const body = JSON.parse(route.request().postData()); sessionStarts.push(body);
      sessionTokenNumber += 1;
      await route.fulfill({ status: 201, contentType: 'application/json', body: JSON.stringify({ sessionToken: `mock-session-${sessionTokenNumber}`, mode: 'AI' }) });
    });
    await page.route('**/api/rpg/health', async route => route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({ status: 'ok', ai: 'configured' }) }));
    await page.route('**/api/rpg/dialogue', async route => {
      const body = JSON.parse(route.request().postData()); dialogueRequests.push(body);
      if (networkFailureNextDialogue) { networkFailureNextDialogue = false; await route.abort(); return; }
      if (body.playerInput === '응답이 늦게 도착합니다.') await new Promise(resolve => { releaseSlowDialogue = resolve; });
      if (fallbackNextDialogue) {
        fallbackNextDialogue = false;
        await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({ fallback: true, mode: 'FALLBACK_PROVIDER', providerErrorCode: 'response_schema_invalid', turn: { sceneId: 'V33_TALK_PRINTER_EKATERINA', beats: [{ speakerId: 'printer_ekaterina', textKo: '형식 검증 실패 대사', emotion: 'focused' }], suggestedReplies: [{ id: 'R1', textKo: '다시 물어볼게요.', tone: 'curious' }, { id: 'R2', textKo: '천천히 확인해요.', tone: 'direct' }] } }) });
        return;
      }
      const line = body.playerInput === '응답이 늦게 도착합니다.' ? 'stale response must not appear' : 'mocked ai line';
      await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({ aiGenerated: true, fallback: false, mode: 'AI', turn: { schemaVersion: 'V33_RPG_DIALOGUE_V1', sceneId: 'V33_TALK_PRINTER_EKATERINA', beats: [{ speakerId: 'printer_ekaterina', textKo: line, emotion: 'focused' }], suggestedReplies: [{ id: 'R1', textKo: '문제 된 줄을 함께 봐요.', tone: 'curious' }, { id: 'R2', textKo: '인쇄비부터 다시 따져봐요.', tone: 'direct' }, { id: 'R3', textKo: '오늘은 조금 더 생각해 봐요.', tone: 'reflective' }] } }) });
    });
    const start = engine.createInitialState({ maps, hostCards: cards, quests });
    start.world.currentMapId = 'printshop';
    start.player.position = { x: 10, y: 13 };
    start.hosts.seamstress_anna.mapId = 'printshop';
    start.hosts.seamstress_anna.position = { x: 11, y: 13 };
    start.hosts.seamstress_anna.relations.workshop = '재확인 요청을 함께 맡았다';
    start.hosts.printer_ekaterina.mapId = 'printshop';
    start.hosts.printer_ekaterina.position = { x: 12, y: 13 };
    const possessed = engine.possessHost(start, 'seamstress_anna', maps.printshop);
    assert.equal(possessed.ok, true);
    const readByAnna = engine.recordSourceRead(possessed.state, 'LIT-TURGENEV-KHOR-KALYNYCH-1847', maps);
    assert.equal(readByAnna.ok, true);
    const completedByAnna = engine.performQuestAction(readByAnna.state, { questId: 'PRINTSHOP_PROOF_1847', hostId: 'seamstress_anna', actionId: 'ASK_FOR_SOURCE', objectId: 20 }, { quests, maps });
    assert.equal(completedByAnna.ok, true);
    const rawSave = engine.saveGame(completedByAnna.state);

    await page.goto(base, { waitUntil: 'networkidle' });
    await page.evaluate(save => { localStorage.clear(); localStorage.setItem('v33-rpg-save', save); }, rawSave);
    await page.reload({ waitUntil: 'domcontentloaded', timeout: 15000 });
    await page.waitForFunction(() => document.querySelector('#bodyname')?.textContent.includes('안나'), undefined, { timeout: 15000 });
    assert.equal(await page.locator('#dialogue-speaker').isVisible(), false, `dialogue portrait should stay hidden before a conversation at ${viewport.width}`);
    const dialogueCountBeforeHealth = dialogueRequests.length, sessionCountBeforeHealth = sessionStarts.length;
    await page.locator('#settings-open').click();
    await page.getByText('서버 키 확인됨 · 모델 응답은 미검증', { exact: true }).waitFor();
    const settingsLayout = await page.locator('#api-settings').evaluate(element => { const rect=element.getBoundingClientRect(); return { width:rect.width,height:rect.height,right:rect.right,bottom:rect.bottom }; });
    assert.ok(settingsLayout.width <= viewport.width && settingsLayout.height <= viewport.height, `API settings dialog fits viewport ${viewport.width}`);
    const initialInquiryBoard = await page.locator('#discussion-quest-board').innerText();
    assert.match(initialInquiryBoard, /사건·철학·이념 임무/);
    assert.match(initialInquiryBoard, /직업이 다른 사람에게도 같은 쟁점/);
    assert.match(initialInquiryBoard, /0\/2 관점/);
    assert.match(initialInquiryBoard, /검열|책에서|명령/);
    assert.equal(dialogueRequests.length, dialogueCountBeforeHealth, 'health probe does not create an AI dialogue');
    assert.equal(sessionStarts.length, sessionCountBeforeHealth, 'health probe does not create an AI session');
    await page.locator('#api-settings-close').click();
    if (viewport.width === 1440) {
      const opinionPrompt = '이 문장이 농노의 삶을 보여준다면, 작가와 인쇄 노동자는 각각 어디까지 책임져야 할까요?';
      fallbackNextDialogue = true;
      await page.locator('#talk').click();
      await page.getByRole('button', { name: opinionPrompt }).click();
      await page.getByRole('button', { name: 'AI 다시 연결' }).waitFor();
      assert.match(await page.locator('#record').textContent(), /AI 응답 생성 실패.*모델 응답 형식 검증 실패/);
      await page.locator('#save').click();
      const failedEvent = await page.evaluate(() => JSON.parse(localStorage.getItem('v33-rpg-save')).state.ledger.findLast(event => event.eventType === 'DIALOGUE_TURN'));
      assert.equal(failedEvent, undefined, 'a failed model generation is not recorded as a completed dialogue turn');
      assert.match(await page.locator('#journal-text').textContent(), /생성 답변을 받지 못했습니다/);
      await page.locator('#settings-open').click();
      await page.getByText('response_schema_invalid', { exact: false }).waitFor();
      assert.equal(await page.locator('#api-diagnostics-list').innerText().then(text => text.includes('response_schema_invalid')), true, 'diagnostics panel displays safe local provider error codes');
      await page.locator('#api-settings-close').click();
      await page.getByRole('button', { name: 'AI 다시 연결' }).click();
      try {
        await page.locator('#journal-text').getByText('mocked ai line', { exact: true }).waitFor();
      } catch {
        throw new Error(`AI retry did not render: requests=${dialogueRequests.length}, starts=${sessionStarts.length}, status=${await page.locator('#record').textContent()}, dialogue=${await page.locator('#journal-text').textContent()}, buttons=${await page.locator('#actions').innerText()}, pageErrors=${errors.join(' | ')}`);
      }
      await page.getByRole('button', { name: '대화 마치기' }).click();
    }
    await page.locator('#talk').click();
    await page.getByLabel('대사 입력').fill('교정쇄를 원문과 대조하고 싶어요.');
    await page.getByRole('button', { name: '말하기' }).click();
    try {
      await page.locator('#journal-text').getByText('mocked ai line', { exact: true }).waitFor({ timeout: 15000 });
    } catch {
      throw new Error(`first AI reply did not render: requests=${dialogueRequests.length}, starts=${sessionStarts.length}, status=${await page.locator('#record').textContent()}, dialogue=${await page.locator('#journal-text').textContent()}, pageErrors=${errors.join(' | ')}`);
    }
    assert.deepEqual(sessionStarts.at(-1), { hostId: 'printer_ekaterina', actorHostId: 'seamstress_anna' });
    assert.deepEqual(dialogueRequests.at(-1).actorRelations, { source_readers: '출처 확인을 먼저 요청했다', workshop: '재확인 요청을 함께 맡았다' });
    assert.deepEqual(dialogueRequests.at(-1).actorActions, [{ questId: 'PRINTSHOP_PROOF_1847', actionId: 'ASK_FOR_SOURCE' }]);
    assert.equal(dialogueRequests.at(-1).sessionToken, `mock-session-${sessionTokenNumber}`);
    if (viewport.width === 1440) {
      const failedText = '생성 답변을 다시 요청합니다.';
      const beforeFailure = dialogueRequests.length;
      await page.locator('#save').click();
      const ledgerBeforeFailure = await page.evaluate(() => JSON.parse(localStorage.getItem('v33-rpg-save')).state.ledger.filter(entry => entry.eventType === 'DIALOGUE_TURN').length);
      networkFailureNextDialogue = true;
      await page.getByLabel('대사 입력').fill(failedText);
      await page.getByRole('button', { name: '말하기' }).click();
      await page.getByRole('button', { name: 'AI 다시 연결' }).waitFor();
      assert.match(await page.locator('#record').textContent(), /AI 연결 실패/);
      assert.match(await page.locator('#journal-text').textContent(), /생성 답변을 받지 못했습니다/);
      await page.locator('#save').click();
      const ledgerAfterFailure = await page.evaluate(() => JSON.parse(localStorage.getItem('v33-rpg-save')).state.ledger);
      assert.equal(ledgerAfterFailure.filter(entry => entry.eventType === 'DIALOGUE_TURN').length, ledgerBeforeFailure, 'a lost provider response is not turned into an authored offline reply');
      await page.getByRole('button', { name: 'AI 다시 연결' }).click();
      await page.locator('#journal-text').getByText('mocked ai line', { exact: true }).waitFor();
      assert.equal(dialogueRequests.length, beforeFailure + 2, 'retry opens a fresh session and resends the unanswered question');
      assert.equal(dialogueRequests.at(-1).playerInput, failedText);
    }
    try { await page.waitForFunction(() => { const image = document.querySelector('#dialogue-portrait'); return image?.complete && image.naturalWidth > 0; }, undefined, { timeout: 5000 }); }
    catch { throw new Error(`dialogue portrait asset failed to load at ${viewport.width}: ${JSON.stringify(await page.locator('#dialogue-portrait').evaluate(image => ({ src:image.src, complete:image.complete, naturalWidth:image.naturalWidth, naturalHeight:image.naturalHeight })))}`); }
    const portrait = await page.locator('#dialogue-portrait').evaluate(image => ({ src: image.getAttribute('src'), alt: image.alt, width: image.naturalWidth, height: image.naturalHeight, visible: image.getBoundingClientRect().width > 0 }));
    assert.match(portrait.src, /portrait-printer_ekaterina\.png$/);
    assert.equal(portrait.width, 64);
    assert.equal(portrait.height, 64);
    assert.equal(portrait.visible, true);
    const layout = await page.evaluate(() => {
      const input = document.querySelector('.dialogue-input').getBoundingClientRect();
      const pad = document.querySelector('.touch-pad').getBoundingClientRect();
      return { documentWidth: document.documentElement.scrollWidth, input: { top: input.top, bottom: input.bottom, visible: input.width > 0 && input.height > 0 && input.top >= 0 && input.bottom <= innerHeight }, inputOverlapsControls: input.left < pad.right && input.right > pad.left && input.top < pad.bottom && input.bottom > pad.top };
    });
    assert.ok(layout.input.visible, `dialogue input is clipped at ${viewport.width}`);
    assert.equal(layout.inputOverlapsControls, false, `dialogue input overlaps movement controls at ${viewport.width}`);
    assert.equal(layout.documentWidth, viewport.width, `horizontal overflow at ${viewport.width}`);
    assert.equal(await page.locator('#actions > button').count(), 4);
    await page.screenshot({ path: path.join(out, `anna-speaks-with-ekaterina-${viewport.width}.png`) });
    await page.locator('#save').click();
    const state = await page.evaluate(() => JSON.parse(localStorage.getItem('v33-rpg-save')).state);
    const event = state.ledger.at(-1);
    assert.equal(event.eventType, 'DIALOGUE_TURN');
    assert.equal(event.hostId, 'printer_ekaterina');
    assert.equal(event.interlocutorHostId, 'seamstress_anna');
    assert.equal(state.quests.PRINTSHOP_PROOF_1847.status, 'resolved');
    if (viewport.width === 1440) assert.equal(state.ledger.findLast(event => event.eventType === 'DIALOGUE_TURN' && event.discussionId)?.discussionId, 'INQUIRY_LITERATURE_AND_SERFDOM');
    assert.equal(errors.length, 0, errors.join('\n'));
    report.viewports.push({ viewport, embodiedHost: 'seamstress_anna', speaker: 'printer_ekaterina', portrait, response: 'mocked AI provider response', questChangedByConversation: false, ...layout, pageErrors: errors });
    if (viewport.width === 1440) {
      const alexeiStart = engine.createInitialState({ maps, hostCards: cards, quests });
      alexeiStart.world.currentMapId = 'printshop';
      alexeiStart.player.position = { x: 10, y: 13 };
      alexeiStart.hosts.clerk_alexei.mapId = 'printshop';
      alexeiStart.hosts.clerk_alexei.position = { x: 10, y: 13 };
      alexeiStart.hosts.clerk_alexei.relations.office_supervisor = '공식 접수 책임을 맡겼다';
      alexeiStart.hosts.printer_ekaterina.mapId = 'printshop';
      alexeiStart.hosts.printer_ekaterina.position = { x: 11, y: 13 };
      const alexeiPossessed = engine.possessHost(alexeiStart, 'clerk_alexei', maps.printshop);
      assert.equal(alexeiPossessed.ok, true);
      await page.evaluate(save => localStorage.setItem('v33-rpg-save', save), engine.saveGame(alexeiPossessed.state));
      await page.reload({ waitUntil: 'networkidle' });
      await page.locator('#talk').click();
      await page.getByLabel('대사 입력').fill('접수 순서와 담당자를 확인하겠습니다.');
      await page.getByRole('button', { name: '말하기' }).click();
      await page.locator('#journal-text').getByText('mocked ai line', { exact: true }).waitFor();
      assert.deepEqual(sessionStarts.at(-1), { hostId: 'printer_ekaterina', actorHostId: 'clerk_alexei' });
      assert.deepEqual(dialogueRequests.at(-1).actorRelations, { office_supervisor: '공식 접수 책임을 맡겼다' });
      assert.deepEqual(dialogueRequests.at(-1).actorActions, [], 'Alexei must not inherit Anna’s completed action context');
      const pairSessions = await page.evaluate(() => Object.entries(sessionStorage).filter(([key]) => key.startsWith('v33-rpg-session:')));
      assert.equal(pairSessions.length, 2);
      assert.equal(new Set(pairSessions.map(([, token]) => token)).size, 2);
      assert.deepEqual(new Set(dialogueRequests.slice(-2).map(request => request.sessionToken)), new Set(pairSessions.map(([, token]) => token)));
      const requestsBeforeSlowTurn = dialogueRequests.length;
      await page.getByLabel('대사 입력').fill('응답이 늦게 도착합니다.');
      await page.locator('.dialogue-input button').click();
      await page.getByRole('button', { name: '답을 기다리는 중' }).waitFor();
      assert.equal(await page.locator('.dialogue-input button').isDisabled(), true, 'submitting is locked while an AI turn is pending');
      await page.waitForFunction(() => true);
      const requestDeadline = Date.now() + 2000;
      while (dialogueRequests.length === requestsBeforeSlowTurn && Date.now() < requestDeadline) await new Promise(resolve => setTimeout(resolve, 10));
      assert.equal(dialogueRequests.length, requestsBeforeSlowTurn + 1, 'pending turn has reached the mock endpoint exactly once');
      const requestCount = dialogueRequests.length;
      await page.locator('.dialogue-input button').evaluate(button => button.click());
      await page.waitForTimeout(100);
      assert.equal(dialogueRequests.length, requestCount, 'a pending turn cannot be submitted twice');
      await page.getByRole('button', { name: '대화 마치기' }).click();
      await page.locator('#talk').click();
      await page.getByLabel('대사 입력').fill('이제 다시 물어보겠습니다.');
      const requestsBeforeReopen = dialogueRequests.length;
      await page.locator('.dialogue-input button').click();
      try {
        await page.locator('#journal-text').getByText('mocked ai line', { exact: true }).waitFor({ timeout: 15000 });
      } catch {
        throw new Error(`reopened AI conversation did not render: requests=${dialogueRequests.length - requestsBeforeReopen}, starts=${sessionStarts.length}, status=${await page.locator('#record').textContent()}, dialogue=${await page.locator('#journal-text').textContent()}, pageErrors=${errors.join(' | ')}`);
      }
      releaseSlowDialogue?.(); releaseSlowDialogue = null;
      await page.waitForTimeout(100);
      assert.equal(await page.getByText('stale response must not appear').count(), 0, 'a response from the closed conversation cannot render in a reopened one');
    }
    await page.close();
  }
  fs.writeFileSync(path.join(out, 'BROWSER_SMOKE.json'), `${JSON.stringify(report, null, 2)}\n`);
  console.log(JSON.stringify(report, null, 2));
} finally {
  await browser.close();
}

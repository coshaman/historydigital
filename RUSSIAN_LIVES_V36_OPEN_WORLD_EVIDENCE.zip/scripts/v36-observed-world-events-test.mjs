import assert from 'node:assert/strict';
import { readFile, readdir } from 'node:fs/promises';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
require('../rpg/engine/game-state.js');
const game = globalThis.V33GameState;
const { purchaseCityProduct, circulateNewspaperIssue, commitSuspiciousAct } = await import('../rpg/engine/civic-life.mjs');
const readJson = async file => JSON.parse(await readFile(new URL(file, import.meta.url), 'utf8'));
const mapFiles = (await readdir(new URL('../rpg/maps/', import.meta.url))).filter(file => file.endsWith('.json'));
const maps = Object.fromEntries(await Promise.all(mapFiles.map(async file => {
  const map = await readJson(`../rpg/maps/${file}`);
  return [map.mapId, map];
})));
const ids = (await readdir(new URL('../rpg/characters/', import.meta.url))).filter(file => file.endsWith('.json'));
const hostCards = await Promise.all(ids.map(file => readJson(`../rpg/characters/${file}`)));
const state = game.createInitialState({ maps, hostCards, startMapId: 'nevsky' });
const playerPosition = { ...state.player.position };

assert.equal(game.playerCanObserveWorldEvent(state, 'nevsky', playerPosition), true,
  'an event at the player tile in the current district is observable');
assert.equal(game.playerCanObserveWorldEvent(state, 'nevsky', { x: playerPosition.x + 7, y: playerPosition.y }), false,
  'an event beyond the observation radius is not disclosed');
assert.equal(game.playerCanObserveWorldEvent(state, 'market-quay', playerPosition), false,
  'an event in another district is not disclosed');

const alexei = state.hosts.clerk_alexei;
alexei.mapId = 'nevsky'; alexei.position = { ...playerPosition };
const possessed = game.possessHost(state, alexei.id, maps.nevsky);
assert.equal(possessed.ok, true);
assert.equal(game.playerCanObserveWorldEvent(possessed.state, 'nevsky', alexei.position), true,
  'observation follows the player while embodied');

function simulateDelivery(observerMapId, observerPosition) {
  const next = game.createInitialState({ maps, hostCards, startMapId: observerMapId });
  next.player.position = { ...observerPosition };
  const sender = next.hosts.courier_pavel, recipient = next.hosts.clerk_alexei;
  sender.mapId = recipient.mapId = 'nevsky';
  sender.position = { x: 12, y: 12 }; recipient.position = { x: 13, y: 12 };
  sender.inventory.push('시험 봉투');
  sender.schedule = [{ atMinute: 540, mapId: 'nevsky', position: { ...sender.position }, activityKo: '봉투를 건넨다', task: {
    id: 'OBSERVATION_TEST_DELIVERY', type: 'DELIVER', recipientHostId: recipient.id, itemKo: '시험 봉투' } }];
  recipient.schedule = [{ atMinute: 540, mapId: 'nevsky', position: { ...recipient.position }, activityKo: '봉투를 받는다' }];
  return game.advanceNpcWorld(next, 1, maps).ledger.flatMap(entry => entry.deliveries ?? [])
    .find(item => item.taskId === 'OBSERVATION_TEST_DELIVERY');
}
const witnessedDelivery = simulateDelivery('nevsky', { x: 11, y: 12 });
const unwitnessedDelivery = simulateDelivery('market-quay', { x: 11, y: 12 });
assert.equal(witnessedDelivery?.witnessedByPlayer, true, 'nearby delivery records a player observation');
assert.equal(unwitnessedDelivery?.witnessedByPlayer, false, 'the same delivery elsewhere stays unknown to the player');

const routineWorld = game.createInitialState({ maps, hostCards, startMapId: 'nevsky' });
const nearbyWorker = routineWorld.hosts.clerk_alexei;
nearbyWorker.mapId = 'nevsky';
nearbyWorker.position = { ...routineWorld.player.position };
nearbyWorker.schedule = [{ atMinute: 540, mapId: 'nevsky', position: { ...nearbyWorker.position }, activityKo: '장부를 정리한다' }];
const routineResult = game.advanceNpcWorld(routineWorld, 6, maps);
const routineEntry = routineResult.ledger.find(entry => entry.eventType === 'NPC_SIMULATION');
assert.ok(routineEntry?.stateChanges?.some(change => change.hostId === nearbyWorker.id && change.witnessedByPlayer),
  'the player can witness and record an NPC beginning a routine');
assert.ok(routineEntry?.goals?.some(goal => goal.hostId === nearbyWorker.id && goal.witnessedByPlayer),
  'the player can witness the resident choosing a concrete daily plan');
assert.match(await readFile(new URL('../rpg/main.js', import.meta.url), 'utf8'), /entry\.stateChanges \?\? \[\].*witnessedByPlayer/,
  'observed routine changes are surfaced in the journal');
assert.match(await readFile(new URL('../rpg/main.js', import.meta.url), 'utf8'), /entry\.goals \?\? \[\].*witnessedByPlayer/,
  'observed plans are surfaced in the journal');

const mainSource = await readFile(new URL('../rpg/main.js', import.meta.url), 'utf8');
assert.match(mainSource, /personalGoalVisits \?\? \[\]\)\.filter\(visit => visit\.witnessedByPlayer\)/,
  'the journal must filter personal life-goal visits to player-witnessed events');
assert.match(mainSource, /personalContacts \?\? \[\]\)\.filter\(contact => contact\.witnessedByPlayer\)/,
  'the journal must filter social reactions to witnessed contacts');
assert.match(mainSource, /deliveries \?\? \[\]\)\.filter\(delivery => delivery\.witnessedByPlayer\)/,
  'the journal must filter deliveries to witnessed events');
assert.match(mainSource, /exchanges \?\? \[\]\)\.filter\(exchange => exchange\.witnessedByPlayer\)/,
  'the journal must filter exchanges to witnessed events');
assert.match(mainSource, /meals \?\? \[\]\)\.filter\(meal => meal\.witnessedByPlayer\)/,
  'the journal must filter meals to witnessed events');
assert.match(mainSource, /restRecoveries \?\? \[\]\)\.filter\(rest => rest\.witnessedByPlayer\)/,
  'the journal must filter rest to witnessed events');

const purchaseWorld = game.createInitialState({ maps, hostCards, startMapId: 'nevsky' });
const purchaseHost = purchaseWorld.hosts.clerk_alexei, moneyBeforePurchase = purchaseHost.money.amount;
const purchase = purchaseCityProduct(purchaseWorld, { hostId: purchaseHost.id, productId: 'newsprint_sheet' });
assert.equal(purchase.ok, true);
assert.equal(purchase.state.hosts[purchaseHost.id].money.amount, moneyBeforePurchase - purchase.product.priceKopeks,
  'a recorded shop purchase changes the resident wallet');
assert.ok(purchase.state.hosts[purchaseHost.id].inventory.includes('newsprint_sheet'),
  'a recorded shop purchase changes carried stock');

const circulationWorld = game.createInitialState({ maps, hostCards, startMapId: 'nevsky' });
circulationWorld.player.civic.publishedIssues.push({ id: 'OBSERVATION_ISSUE', titleKo: '시험 호외', storyId: 'LITERARY_RURAL_LIFE_1847' });
circulationWorld.hosts.clerk_alexei.inventory.push('newspaper_issue:OBSERVATION_ISSUE');
const circulation = circulateNewspaperIssue(circulationWorld, { hostId: 'clerk_alexei', issueId: 'OBSERVATION_ISSUE', route: 'street' });
assert.equal(circulation.ok, true);
assert.ok(!circulation.state.hosts.clerk_alexei.inventory.includes('newspaper_issue:OBSERVATION_ISSUE'),
  'public circulation removes the issue from office stock');
assert.equal(circulation.state.player.civic.circulatedIssues.at(-1).route, 'street',
  'public circulation records the new audience');

const custodyWorld = game.createInitialState({ maps, hostCards, startMapId: 'nevsky' });
const custodyHost = custodyWorld.hosts.courier_pavel;
const embodied = game.possessHost(custodyWorld, custodyHost.id, maps.nevsky);
assert.equal(embodied.ok, true);
const custody = commitSuspiciousAct(embodied.state, { hostId: custodyHost.id, actId: 'OPEN_SEALED_DISPATCH', witnessIds: ['printer_ekaterina'], maps });
assert.equal(custody.ok, true);
assert.equal(custody.arrested, true);
assert.equal(custody.state.player.civic.custody.active, true,
  'a witnessed act produces an explicit police response');

for (const eventType of ['CITY_PURCHASE', 'NEWSPAPER_CIRCULATED', 'POLICE_CUSTODY']) {
  assert.ok(purchase.state.ledger.some(entry => entry.eventType === eventType)
    || circulation.state.ledger.some(entry => entry.eventType === eventType)
    || custody.state.ledger.some(entry => entry.eventType === eventType), `${eventType} must be recorded`);
  assert.ok(mainSource.includes(`entry.eventType === '${eventType}'`), `${eventType} must be visible in the player journal`);
}

console.log(JSON.stringify({ status: 'PASS', currentDistrictAndRangeRequired: true,
  embodiedPlayerPositionUsed: true, witnessedDelivery: true, remoteDeliveryWithheld: true,
  witnessedRoutineChange: true, witnessedDailyPlan: true, witnessedNpcBehaviorFamilies: 9,
  playerVisibleCivicConsequenceFamilies: 3, journalEventFamiliesFiltered: 12 }));

import { chromium } from 'playwright';
import { mkdir, writeFile } from 'node:fs/promises';

const browser = await chromium.launch({headless:true});
const context = await browser.newContext({viewport:{width:1440,height:900},deviceScaleFactor:1});
const page = await context.newPage();
const baseUrl = process.env.CHANCERY_BASE_URL || 'http://127.0.0.1:4173';
await page.goto(`${baseUrl}/chancery.html#legacy`, {waitUntil:'domcontentloaded',timeout:15000});
await page.waitForFunction(() => window.__threeRuntime && window.__goldRuntime, null, {timeout:15000});
const result = await page.evaluate(async () => {
  const gate = window.__threeRuntime;
  if (!gate?.loaded || !gate.local || gate.fallback || !gate.renderer?.info || !document.querySelector('#deskCanvas')?.dataset.threeLoaded) throw new Error('real local WebGL gate failed');
  const gl = gate.renderer.getContext();
  const debug = gl.getExtension('WEBGL_debug_renderer_info');
  const renderer = debug ? gl.getParameter(debug.UNMASKED_RENDERER_WEBGL) : gl.getParameter(gl.RENDERER);
  const vendor = debug ? gl.getParameter(debug.UNMASKED_VENDOR_WEBGL) : gl.getParameter(gl.VENDOR);
  const samples = async (label) => {
    const frames = await new Promise(resolve => { const values=[]; let previous=performance.now(); let count=0; const tick=now=>{ if(count++) values.push(now-previous); previous=now; if(count<31) requestAnimationFrame(tick); else resolve(values.slice(1)); }; requestAnimationFrame(tick); });
    const sorted=[...frames].sort((a,b)=>a-b); const percentile=p=>sorted[Math.min(sorted.length-1,Math.floor(sorted.length*p))];
    return {label, frameTimeMedian:percentile(.5), frameTimeP95:percentile(.95), fpsMedian:1000/percentile(.5), fpsP95:1000/percentile(.95), metrics:gate.getMetrics()};
  };
  const idle=await samples('idle');
  await window.__goldRuntime.selectGoldExcerpt('E02-X2');
  const pickup=await samples('document-pickup');
  document.querySelector('#sourceBtn').click();
  const drawer=await samples('drawer-interaction');
  document.querySelector('#closeDrawer').click();
  document.querySelector('#petersburgWindow').dispatchEvent(new MouseEvent('click',{bubbles:true}));
  const windowInteraction=await samples('window-interaction');
  const softwareRenderer = /swiftshader|llvmpipe|software rasterizer|software renderer/i.test(renderer);
  return {schemaVersion:'V36_DESK_WEBGL_PERFORMANCE_V1',measuredAt:new Date().toISOString(),environment:{browser:navigator.userAgent,platform:navigator.platform,hardwareConcurrency:navigator.hardwareConcurrency,devicePixelRatio,renderer,vendor,softwareRenderer,hardwareGpuVerified:false},gate:{loaded:gate.loaded,local:gate.local,fallback:gate.fallback,canvas:gate.canvas.dataset.threeLoaded},samples:[idle,pickup,drawer,windowInteraction]};
});
const reportPath = new URL('../docs/v36/current-audit/DESK_WEBGL_PERFORMANCE.json', import.meta.url);
await mkdir(new URL('../docs/v36/current-audit/', import.meta.url), {recursive:true});
await writeFile(reportPath, JSON.stringify(result,null,2));
console.log(JSON.stringify(result,null,2));
await browser.close();

# SDD ledger — plan: docs/superpowers/plans/2026-10-16-circle-exam-life-simulation.md

BASE: de1f21be15540f459b7058f768ebdcc7de9c0610 (latest pushed V33 base); worktree codex/v33-possession-rpg.

Ruling: The approved plan originally names the superseded MAIN20 runtime; its own execution record specifies that the same approved feature was integrated in V33. Continue auditing and patch V33 interfaces, not the archived MAIN20 runtime — this follows the approved spec while avoiding two disconnected game paths. Cost if wrong: tests may target legacy behavior; mitigated by the V33 browser campaign and source-contract tests.

Task 1: Existing execution record documents source inventory, save migration, runtime phases, and ending integration. Follow-up acceptance: `npm run acceptance:v33` has passed in the extracted ZIP before this follow-up. Source provenance audit passed. Current commit baseline is clean and equals origin/master.

Task 2–6: Approved learning units, identical five-question exam, pure scoring reducer, save migration, seven-episode fictional timeline, and ending UI already exist in V33. Follow-up found two missing proof/edge cases: malformed extra answer keys could still pass; browser ending test did not assert timeline order/playback state isolation. These are being addressed test-first.

Task 7: Existing acceptance covers representative ending routes, source audit, and desktop/mobile browser campaign. Still track exact exhaustive route-vector and live/human external gates separately; do not infer them from representative route tests.
